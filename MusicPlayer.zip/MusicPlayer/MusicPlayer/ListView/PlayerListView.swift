//
//  PlayerListView.swift
//  MusicPlayer
//
//  Created by Pranith Kumar Margam on 14/09/23.
//

import SwiftUI

struct AlbumListView: View {
    @StateObject private var playerListStore = PlayerListStore()
    var body: some View {
        NavigationView {
            List(0 ..< playerListStore.albums.count,id: \.self) { index in
                NavigationLink(destination: {
                    PlayerView()
                },
                label:{
                    AlbumCard(album: playerListStore.albums[index])
                })
            }
        }
    }
}

struct PlayerListView_Previews: PreviewProvider {
    static var previews: some View {
        AlbumListView()
    }
}


struct AlbumCard: View {
    var album: Album
    var body: some View {
        VStack {
            Text(album.title)
            Text("artist")
            Text("album")
            Text("duration")
        }
    }
}
