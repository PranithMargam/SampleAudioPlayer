//
//  PlayerListStore.swift
//  MusicPlayer
//
//  Created by Pranith Kumar Margam on 14/09/23.
//

import Foundation

class PlayerListStore: ObservableObject {
    @Published var albums: [Album] = []
    private var apiClient: APIClient
    init(apiClient: APIClient = APIClient()) {
        self.apiClient = apiClient
        Task {
            await self.fetchAlbums()
        }
    }
    
    func fetchAlbums() async {        
        do {
            let albums = try await self.apiClient.fetchAlbums(urlString: "urlString")
            DispatchQueue.main.async {
                self.albums = albums
            }
        }catch let err {
            //handle error case
            print(err)
        }
    }
    
    private func creatAlbum(name: String) -> Album {
        Album(title: name, artist: "artist name", album: "album name", duration: "album duration")
    }
}
