//
//  Album.swift
//  MusicPlayer
//
//  Created by Pranith Kumar Margam on 14/09/23.
//

import Foundation

struct Album: Codable,Equatable {
    let title: String
    let artist: String
    let album: String
    let duration: String
}
