//
//  ContentView.swift
//  MusicPlayer
//
//  Created by Pranith Kumar Margam on 14/09/23.
//

import SwiftUI
import AVKit

struct PlayerView: View {
    @State var player = AVPlayer(url: URL(string: "https://www.learningcontainer.com/wp-content/uploads/2020/02/Kalimba.mp3")!)
    @State private var isPlaying: Bool = false
    @State private var volume: Float = 0
    var body: some View {
        VStack {
            VideoPlayer(player: player)
                .frame(width: 200,height: 200)
            Spacer()
                .frame(height: 16)
            HStack {
                Button(action: {
                    self.isPlaying ? player.pause() : player.play()
                    self.isPlaying.toggle()
                    
                    print(player.volume)
                    
                }) {
                    Image(systemName: self.isPlaying ? "play" : "pause")
                        .frame(width: 60,height: 60)
                        .foregroundColor(.red)
                        .fontWeight(.bold)
                }
               
                
                Button(action: {
                    self.volume = max(self.volume - 0.1, 0) //0.1
                    player.volume = self.volume
                    
                }) {
                    Image(systemName: "minus")
                        .frame(width: 60,height: 60)
                        .foregroundColor(.red)
                        .fontWeight(.bold)
                }
                
                Button(action: {
                    self.volume = min(self.volume + 0.1, 1.0) //0.1
                    player.volume = self.volume
                    
                }) {
                    Image(systemName: "plus")
                        .frame(width: 60,height: 60)
                        .foregroundColor(.red)
                        .fontWeight(.bold)
                }
            }
        }
        .onAppear {
            self.player.play()
            self.isPlaying = true
            self.volume = player.volume
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        PlayerView()
    }
}
