//
//  MusicPlayerApp.swift
//  MusicPlayer
//
//  Created by Pranith Kumar Margam on 14/09/23.
//

import SwiftUI

@main
struct MusicPlayerApp: App {
    var body: some Scene {
        WindowGroup {
            AlbumListView()
        }
    }
}
