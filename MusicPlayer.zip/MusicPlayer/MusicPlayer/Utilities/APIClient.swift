//
//  APIClient.swift
//  MusicPlayer
//
//  Created by Pranith Kumar Margam on 14/09/23.
//

import Foundation

enum APIError: Error {
    case invalidURLString
    case connectionError(Error)
}

class APIClient {
    let session: URLSession
    
    init(session: URLSession = .shared) {
        self.session = session
    }
    
    func fetchAlbums(urlString: String) async throws -> [Album] {
        guard let _ = URL(string: urlString) else {
            throw APIError.invalidURLString
        }
        do {
            //let (data,response) = try await session.data(from: url)
            //
            var albums:[Album] = []
            for i in 0...5 {
                let album = creatAlbum(name: "Album\(i)")
                albums.append(album)
            }
            return albums
        }catch let error {
            throw APIError.connectionError(error)
        }
    }
    
    private func creatAlbum(name: String) -> Album {
        Album(title: name, artist: "artist name", album: "album name", duration: "album duration")
    }
}


